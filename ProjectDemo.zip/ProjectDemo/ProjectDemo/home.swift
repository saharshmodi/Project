//
//  home.swift
//  ProjectDemo
//
//  Created by MAC2 on 13/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import EasySocialButton

class home: UIViewController {
    @IBOutlet weak var subview: UIView!
    
  //  @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var imgview: UIImageView!
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.navigationBar.isHidden = true
        
        imgview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        self.subview.frame = CGRect(x: 0, y: self.view.frame.height - 330 , width: self.view.frame.width, height: 330)
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 0.5
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 0.7
        
        let socialButton = AZSocialButton(frame: CGRect(x: 35, y: 40, width: 300, height: 40))
        
        socialButton.animateInteraction = true
        socialButton.useCornerRadius = true
        socialButton.cornerRadius = 5
        socialButton.highlightOnTouch = false
        socialButton.setImage(UIImage(named: "fb.png"), for: .normal)
        socialButton.setTitle("    Sign in with Facebook", for: [])
        socialButton.setTitleColor(.blue, for: [])
        socialButton.backgroundColor = UIColor.white
        socialButton.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        
        
        socialButton.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        let socialButton1 = AZSocialButton(frame: CGRect(x: 35, y: 110, width: 300, height: 40))
        
        socialButton1.animateInteraction = true
        socialButton1.useCornerRadius = true
        socialButton1.cornerRadius = 5
        socialButton1.highlightOnTouch = false
        socialButton1.setImage(UIImage(named: "google.png"), for: .normal)
        socialButton1.setTitle("    Sign in with Google", for: [])
        socialButton1.setTitleColor(.red, for: [])
        socialButton1.backgroundColor = UIColor.red
        socialButton1.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        
        
        socialButton1.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        let socialButton2 = AZSocialButton(frame: CGRect(x: 35, y: 180, width: 300, height: 40))
        
        socialButton2.animateInteraction = true
        socialButton2.useCornerRadius = true
        socialButton2.cornerRadius = 5
        socialButton2.highlightOnTouch = false
        socialButton2.setImage(UIImage(named: "email.png"), for: .normal)
        socialButton2.setTitle("    Sign in with Email", for: [])
        socialButton2.setTitleColor(.black, for: [])
        
        socialButton2.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        
        
        socialButton2.onClickAction = { (button) in
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
            self.navigationController?.pushViewController(stb!, animated: true)
            
        }
        
       // btn.frame = CGRect(x: 125, y: 235, width: 100, height: 30)
        
        self.subview.addSubview(socialButton);
        self.subview.addSubview(socialButton1);
        self.subview.addSubview(socialButton2);
 
        // Do any additional setup after loading the view.
    }
   /* @IBAction func btnClick(_ sender: Any) {
        
        
    }*/
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
